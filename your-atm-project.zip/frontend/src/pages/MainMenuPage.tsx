import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function MainMenuPage() {
  const navigate = useNavigate();

  // Handlers for transaction options
  const handleCheckBalance = () => {
    console.log("Navigate to Check Balance");
    navigate("/BalanceInquiryPage"); // Navigate to Balance Inquiry
  };

  const handleWithdrawCash = () => {
    console.log("Navigate to Withdraw Cash");
    navigate("/WithdrawalAmountPage"); // Navigate to Withdrawal Amount Selection
  };

  const handleDeposit = () => {
    console.log("Navigate to Deposit");
    // navigate("/deposit"); // Placeholder
  };

  const handleTransfer = () => {
    console.log("Navigate to Transfer");
    // navigate("/transfer"); // Placeholder
  };

  const handleExit = () => {
    console.log("Exiting - Navigate to Home");
    navigate("/"); // Navigate back to the landing page
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold">Main Menu</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-8">
          {/* Transaction Buttons */}
          <Button variant="outline" size="lg" className="h-20 text-lg font-semibold" onClick={handleCheckBalance}>
            Check Balance
          </Button>
          <Button variant="outline" size="lg" className="h-20 text-lg font-semibold" onClick={handleWithdrawCash}>
            Withdraw Cash
          </Button>
          <Button variant="outline" size="lg" className="h-20 text-lg font-semibold" onClick={handleDeposit}>
            Deposit
          </Button>
          <Button variant="outline" size="lg" className="h-20 text-lg font-semibold" onClick={handleTransfer}>
            Transfer
          </Button>
          <Button variant="destructive" size="lg" className="md:col-span-2 h-16 text-lg font-semibold mt-4" onClick={handleExit}>
            Exit / Cancel
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
