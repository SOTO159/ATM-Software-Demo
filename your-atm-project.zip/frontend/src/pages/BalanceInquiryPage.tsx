import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function BalanceInquiryPage() {
  const navigate = useNavigate();

  // Placeholder data - replace with actual data fetching later
  const currentBalance = "$5,432.10";
  const availableBalance = "$5,100.00";

  // Handlers for buttons
  const handlePrintReceipt = () => {
    console.log("Print Receipt clicked");
    // Placeholder for actual receipt printing logic
    alert("Receipt printing is not implemented yet.");
  };

  const handleReturnToMenu = () => {
    console.log("Return to Main Menu clicked");
    navigate("/MainMenuPage"); // Navigate back to the main menu
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold">Account Balance</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6 p-8">
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Current Balance:</span>
              <span className="text-lg font-semibold">{currentBalance}</span>
            </div>
            <Separator />
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Available Balance:</span>
              <span className="text-lg font-semibold">{availableBalance}</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-4 pt-4">
          <Button variant="outline" size="lg" onClick={handlePrintReceipt}>
            Print Receipt
          </Button>
          <Button variant="primary" size="lg" onClick={handleReturnToMenu}>
            Return to Menu
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
