
import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function WithdrawalAmountPage() {
  const navigate = useNavigate();

  const quickAmounts = [20, 40, 60, 100, 200];

  // Handler for quick amount selection
  const handleQuickAmount = (amount: number) => {
    console.log(`Quick Amount selected: $${amount}`);
    // Navigate to confirmation page (to be created)
    navigate(`/WithdrawalConfirmationPage?amount=${amount}`); // Navigate to confirmation page
  };

  // Handler for custom amount button
  const handleCustomAmount = () => {
    console.log("Custom Amount selected");
    // Navigate to custom amount entry page (to be created)
    // navigate("/custom-amount-entry"); // Example navigation
    alert("Custom amount entry screen next.");
  };

  // Handler for Cancel button
  const handleCancel = () => {
    console.log("Withdrawal cancelled, returning to Main Menu");
    navigate("/MainMenuPage"); // Navigate back to the main menu
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-lg shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold">Select Withdrawal Amount</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-6 p-8">
          {/* Quick Amount Buttons */}
          {quickAmounts.map((amount) => (
            <Button
              key={amount}
              variant="outline"
              size="lg"
              className="h-20 text-lg font-semibold"
              onClick={() => handleQuickAmount(amount)}
            >
              ${amount}
            </Button>
          ))}
          {/* Custom Amount Button */}
          <Button
            variant="outline"
            size="lg"
            className="h-20 text-lg font-semibold"
            onClick={handleCustomAmount}
          >
            Custom Amount
          </Button>
        </CardContent>
        <CardFooter className="pt-4 flex justify-center">
            <Button variant="secondary" size="lg" className="w-1/2" onClick={handleCancel}>Cancel</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
