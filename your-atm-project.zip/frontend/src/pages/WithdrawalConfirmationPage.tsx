import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react"; // For loading spinner
import { toast } from "sonner"; // For showing errors
import brain from "brain";
import type { RecordTransactionRequest, RecordTransactionResponse } from "types";

export default function WithdrawalConfirmationPage() {
  const navigate = useNavigate();
  const location = useLocation();


  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get amount from query parameters
  const queryParams = new URLSearchParams(location.search);
  const amountString = queryParams.get("amount");
  const amount = Number(amountString);

  // Handler for Confirm button
  const handleConfirm = async () => {
    if (isNaN(amount) || amount <= 0) {
      toast.error("Invalid withdrawal amount.");
      return;
    }

    setIsLoading(true);
    setError(null);
    console.log(`Attempting withdrawal of $${amount}`);

    const requestBody: RecordTransactionRequest = {
      account_id: "123456", // Using default account ID
      transaction_type: "withdrawal",
      amount: amount,
    };

    try {
      const response = await brain.record_transaction(requestBody);
      const data: RecordTransactionResponse = await response.json();

      if (response.ok && data.success) {
        console.log("Withdrawal successful via API. New balance:", data.new_balance);
        toast.success("Withdrawal successful!");
        // Navigate to success screen
        navigate(
          `/TransactionSuccessPage?type=Withdrawal&amount=${amount}&newBalance=${data.new_balance}`
        );
      } else {
        // Handle business logic errors (e.g., insufficient funds)
        const errorMessage = data.message || "Withdrawal failed. Please try again.";
        console.error("API reported failure:", errorMessage);
        toast.error(errorMessage);
        setError(errorMessage); // Optionally store error state
      }
    } catch (err) {
      // Handle network or unexpected errors
      console.error("Error during withdrawal API call:", err);
      const errorMessage = "An unexpected error occurred during withdrawal.";
      toast.error(errorMessage);
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  // Handler for Cancel button
  const handleCancel = () => {
    console.log("Withdrawal confirmation cancelled, returning to amount selection");
    // Option 1: Go back to amount selection
    navigate("/WithdrawalAmountPage");
    // Option 2: Go back to Main Menu (could be argued either way)
    // navigate("/MainMenuPage");
  };

  // Basic validation/fallback if amount is missing
  if (!amount || isNaN(Number(amount))) {
    console.error("Invalid or missing amount for confirmation.");
    // Redirect back or show an error
    // For now, let's just show a message and allow cancel
    return (
      <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
        <Card className="w-full max-w-md shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-xl font-bold text-destructive">Error</CardTitle>
          </CardHeader>
          <CardContent className="p-8 text-center">
            <p>Invalid or missing withdrawal amount specified.</p>
          {error && <p className="text-sm text-destructive mt-2">Error: {error}</p>}
          </CardContent>
          <CardFooter className="pt-4 flex justify-center">
            <Button variant="secondary" size="lg" onClick={handleCancel} disabled={isLoading}>Go Back</Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold">Confirm Withdrawal</CardTitle>
          <CardDescription className="text-lg pt-2">Please confirm you wish to withdraw:</CardDescription>
        </CardHeader>
        <CardContent className="p-8 text-center space-y-4">
          <p className="text-3xl font-bold text-primary">${Number(amount).toFixed(2)}</p>
          <p className="text-sm text-muted-foreground">
            This amount will be debited from your account.
          </p>
          {error && <p className="text-sm text-destructive mt-2">Error: {error}</p>} {/* Display error if any */}
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-4 pt-4">
          <Button variant="secondary" size="lg" onClick={handleCancel} disabled={isLoading}>Cancel</Button>
          <Button variant="primary" size="lg" className="bg-green-600 hover:bg-green-700" onClick={handleConfirm} disabled={isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {isLoading ? "Processing..." : "Confirm"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
