
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input"; // Using Input for PIN display

export default function PinEntryPage() {
  const [pin, setPin] = useState<string>("");
  const navigate = useNavigate();

  const MAX_PIN_LENGTH = 4;

  // Handler for numeric button clicks
  const handleNumberClick = (digit: string) => {
    if (pin.length < MAX_PIN_LENGTH) {
      setPin(pin + digit);
    }
  };

  // Handler for Clear button
  const handleClear = () => {
    setPin("");
  };

  // Handler for Cancel button
  const handleCancel = () => {
    console.log("Cancel clicked - navigating to home");
    navigate("/"); // Navigate back to the landing page
  };

  // Handler for Enter button
  const handleEnter = () => {
    if (pin.length === MAX_PIN_LENGTH) {
      console.log(`PIN entered: ${pin} - validating...`);
      // Placeholder for actual PIN validation logic
      // For now, just log and potentially navigate to main menu
      navigate("/MainMenuPage"); // Navigate to the Main Menu page
    } else {
      console.log("PIN too short");
      // Maybe show an error message to the user
    }
  };

  // Generate keypad buttons
  const keypadNumbers = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"];

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-sm shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold">Enter Your PIN</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* PIN Display - using Input component styled for password */}
          <div className="flex justify-center">
            <Input
              type="password" // Masks the input
              value={pin} // Display the current PIN
              readOnly // Prevent direct typing
              maxLength={MAX_PIN_LENGTH}
              className="w-3/4 text-center text-2xl tracking-[0.5em] font-mono bg-muted"
              aria-label="PIN Display"
            />
          </div>

          {/* Numeric Keypad */}
          <div className="grid grid-cols-3 gap-3">
            {keypadNumbers.map((num) => (
              <Button
                key={num}
                variant="outline"
                size="lg"
                className={`text-xl font-semibold ${num === '0' ? 'col-start-2' : ''}`}
                onClick={() => handleNumberClick(num)}
              >
                {num}
              </Button>
            ))}
          </div>
        </CardContent>
        <CardFooter className="grid grid-cols-3 gap-3 pt-4">
            {/* Action Buttons */}
            <Button variant="destructive" size="lg" className="font-semibold" onClick={handleCancel}>Cancel</Button>
            <Button variant="secondary" size="lg" className="font-semibold" onClick={handleClear}>Clear</Button>
            <Button variant="primary" size="lg" className="font-semibold bg-green-600 hover:bg-green-700" onClick={handleEnter}>Enter</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
