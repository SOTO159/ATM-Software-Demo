import React from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion"; // for animation

export default function App() {
  const navigate = useNavigate();

  const handleCardInsert = () => {
    console.log("Card inserted - navigate to PIN entry");
    navigate("/PinEntryPage");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#f6f6f6] p-4">
      <Card className="w-full max-w-md shadow-xl rounded-2xl">
        <CardHeader className="text-center bg-[#b3251e] text-white p-6 rounded-t-2xl">
          <CardTitle className="text-2xl font-bold leading-snug">
            Aaditya Khanna, Adityavir Singh Randhawa, Omkar Nimbalkar BANK
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8 space-y-6 text-center">
          <p className="text-lg text-gray-600">
            Please insert or swipe your card to begin.
          </p>
          {/* Card Slot Visual with slight hover glow */}
          <motion.div 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex justify-center items-center h-24 bg-gray-100 rounded-md border border-gray-300"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-gray-400 opacity-50"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/></svg>
          </motion.div>
          {/* Button */}
          <Button 
            size="lg" 
            className="w-full font-semibold bg-[#b3251e] hover:bg-[#9a1e19] text-white rounded-xl"
            onClick={handleCardInsert}
            aria-label="Insert Card"
          >
            Simulate Card Insertion
          </Button>
          <p className="text-sm text-gray-500 pt-4">
            For assistance, please contact support.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
