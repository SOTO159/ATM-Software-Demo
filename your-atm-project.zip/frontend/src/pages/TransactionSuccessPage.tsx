import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function TransactionSuccessPage() {
  const navigate = useNavigate();
  const location = useLocation();

  // Get details from query parameters (passed from previous screen)
  const queryParams = new URLSearchParams(location.search);
  const transactionType = queryParams.get("type") || "Transaction"; // e.g., Withdrawal, Deposit
  const amount = queryParams.get("amount") || "N/A";
  const newBalance = queryParams.get("newBalance") || "N/A";

  // Format details for display
  const formattedAmount = !isNaN(Number(amount)) ? `$${Number(amount).toFixed(2)}` : amount;
  const formattedBalance = !isNaN(Number(newBalance)) ? `$${Number(newBalance).toFixed(2)}` : newBalance;

  // Handler for printing receipt
  const handlePrintReceipt = () => {
    console.log("Print Receipt clicked");
    // Placeholder for simulated receipt display/logic
    alert(
`--- Receipt --- 
Type: ${transactionType}
Amount: ${formattedAmount}
New Balance: ${formattedBalance}
----------------`
    );
  };

  // Handler for returning to menu
  const handleReturnToMenu = () => {
    console.log("Return to Main Menu clicked");
    navigate("/MainMenuPage");
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-secondary p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-xl font-bold text-green-600">Success!</CardTitle>
          <CardDescription className="text-lg pt-2">
            {transactionType} completed successfully.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 p-8">
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">Amount:</span>
            <span className="text-lg font-semibold">{formattedAmount}</span>
          </div>
          <Separator />
          <div className="flex justify-between items-center">
            <span className="text-muted-foreground">New Balance:</span>
            <span className="text-lg font-semibold">{formattedBalance}</span>
          </div>
        </CardContent>
        <CardFooter className="grid grid-cols-2 gap-4 pt-4">
          <Button variant="outline" size="lg" onClick={handlePrintReceipt}>
            Print Receipt
          </Button>
          <Button variant="primary" size="lg" onClick={handleReturnToMenu}>
            Return to Menu
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
