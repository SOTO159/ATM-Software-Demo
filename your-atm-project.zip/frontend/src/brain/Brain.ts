import {
  CheckHealthData,
  GetAccountInfoData,
  GetAccountInfoError,
  GetAccountInfoParams,
  RecordTransactionData,
  RecordTransactionError,
  RecordTransactionRequest,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Retrieves the balance information for the specified account. Currently defaults to account '123456'.
   *
   * @tags Account Data, dbtn/module:account_data
   * @name get_account_info
   * @summary Get Account Info
   * @request GET:/routes/account/info
   */
  get_account_info = (query: GetAccountInfoParams, params: RequestParams = {}) =>
    this.request<GetAccountInfoData, GetAccountInfoError>({
      path: `/routes/account/info`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Records a transaction (currently only 'withdrawal') for the specified account, updates the balance, and stores the transaction history.
   *
   * @tags Account Data, dbtn/module:account_data
   * @name record_transaction
   * @summary Record Transaction
   * @request POST:/routes/account/transaction
   */
  record_transaction = (data: RecordTransactionRequest, params: RequestParams = {}) =>
    this.request<RecordTransactionData, RecordTransactionError>({
      path: `/routes/account/transaction`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });
}
