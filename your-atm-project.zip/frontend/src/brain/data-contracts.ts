/** GetAccountInfoResponse */
export interface GetAccountInfoResponse {
  /** Account Id */
  account_id: string;
  /** Current Balance */
  current_balance: number;
  /** Available Balance */
  available_balance: number;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** RecordTransactionRequest */
export interface RecordTransactionRequest {
  /**
   * Account Id
   * @default "123456"
   */
  account_id?: string;
  /** Transaction Type */
  transaction_type: string;
  /** Amount */
  amount: number;
}

/** RecordTransactionResponse */
export interface RecordTransactionResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** New Balance */
  new_balance?: number | null;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

export type CheckHealthData = HealthResponse;

export interface GetAccountInfoParams {
  /**
   * Account Id
   * @default "123456"
   */
  account_id?: string;
}

export type GetAccountInfoData = GetAccountInfoResponse;

export type GetAccountInfoError = HTTPValidationError;

export type RecordTransactionData = RecordTransactionResponse;

export type RecordTransactionError = HTTPValidationError;
