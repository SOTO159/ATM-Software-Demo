import { CheckHealthData, GetAccountInfoData, RecordTransactionData, RecordTransactionRequest } from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Retrieves the balance information for the specified account. Currently defaults to account '123456'.
   * @tags Account Data, dbtn/module:account_data
   * @name get_account_info
   * @summary Get Account Info
   * @request GET:/routes/account/info
   */
  export namespace get_account_info {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Account Id
       * @default "123456"
       */
      account_id?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAccountInfoData;
  }

  /**
   * @description Records a transaction (currently only 'withdrawal') for the specified account, updates the balance, and stores the transaction history.
   * @tags Account Data, dbtn/module:account_data
   * @name record_transaction
   * @summary Record Transaction
   * @request POST:/routes/account/transaction
   */
  export namespace record_transaction {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = RecordTransactionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = RecordTransactionData;
  }
}
