import databutton as db
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import re

router = APIRouter()

DEFAULT_ACCOUNT_ID = "123456" # Default account for this simulation

# --- Pydantic Models ---

class AccountInfo(BaseModel):
    account_id: str
    balance: float
    # We'll add transaction list later if needed by other features

class GetAccountInfoResponse(BaseModel):
    account_id: str
    current_balance: float
    available_balance: float # For simplicity, same as current for now

# --- Helper Functions ---

def sanitize_storage_key(key: str) -> str:
    """Sanitize storage key to only allow alphanumeric and ._- symbols"""
    return re.sub(r'[^a-zA-Z0-9._-]', '', key)

def get_account_data(account_id: str) -> dict:
    """Retrieves account data from db.storage, initializes if not found."""
    storage_key = sanitize_storage_key(f"account_{account_id}_data")
    try:
        account_data = db.storage.json.get(storage_key)
        print(f"Retrieved data for account {account_id}")
        return account_data
    except FileNotFoundError:
        print(f"No data found for account {account_id}. Initializing.")
        # Initialize with default structure and balance
        default_data = {
            "account_id": account_id,
            "balance": 5000.00, # Starting balance
            "transactions": [] # Initialize empty transaction history
        }
        db.storage.json.put(storage_key, default_data)
        print(f"Initialized account {account_id} with balance ${default_data['balance']}")
        return default_data

# --- API Endpoints ---

@router.get("/account/info", response_model=GetAccountInfoResponse, tags=["Account Data"])
def get_account_info(account_id: str = DEFAULT_ACCOUNT_ID):
    """
    Retrieves the balance information for the specified account.
    Currently defaults to account '123456'.
    """
    print(f"Attempting to get info for account: {account_id}")
    if account_id != DEFAULT_ACCOUNT_ID:
        # In a real app, you'd check if the user is authorized for this account
        # For this simulation, we only support the default account
        raise HTTPException(status_code=404, detail="Account not found or access denied.")

    account_data = get_account_data(account_id)
    balance = account_data.get("balance", 0.0) # Default to 0 if key missing somehow

    print(f"Account {account_id} balance: ${balance}")

    return GetAccountInfoResponse(
        account_id=account_id,
        current_balance=balance,
        available_balance=balance # Keeping it simple for now
    )

from datetime import datetime, timezone

class TransactionRecord(BaseModel):
    timestamp: str
    type: str # e.g., 'withdrawal', 'deposit', 'initial_balance'
    amount: float
    new_balance: float

class RecordTransactionRequest(BaseModel):
    account_id: str = DEFAULT_ACCOUNT_ID
    transaction_type: str # Currently expecting 'withdrawal'
    amount: float

class RecordTransactionResponse(BaseModel):
    success: bool
    message: str
    new_balance: float | None = None


def update_account_data(account_id: str, data: dict):
    """Saves updated account data to db.storage."""
    storage_key = sanitize_storage_key(f"account_{account_id}_data")
    try:
        db.storage.json.put(storage_key, data)
        print(f"Successfully updated data for account {account_id}")
    except Exception as e:
        print(f"Error updating account data for {account_id}: {e}")
        # Depending on requirements, might want to raise exception here
        raise HTTPException(status_code=500, detail="Failed to save transaction data.")


@router.post("/account/transaction", response_model=RecordTransactionResponse, tags=["Account Data"])
def record_transaction(request: RecordTransactionRequest):
    """
    Records a transaction (currently only 'withdrawal') for the specified account,
    updates the balance, and stores the transaction history.
    """
    print(f"Received transaction request for account {request.account_id}: Type={request.transaction_type}, Amount={request.amount}")
    if request.account_id != DEFAULT_ACCOUNT_ID:
        raise HTTPException(status_code=404, detail="Account not found or access denied.")

    if request.transaction_type.lower() != 'withdrawal':
        raise HTTPException(status_code=400, detail="Only 'withdrawal' transactions are currently supported.")

    if request.amount <= 0:
        raise HTTPException(status_code=400, detail="Withdrawal amount must be positive.")

    account_data = get_account_data(request.account_id)
    current_balance = account_data.get("balance", 0.0)

    print(f"Current balance for account {request.account_id}: ${current_balance}")

    if current_balance < request.amount:
        print(f"Insufficient funds for withdrawal. Balance: {current_balance}, Requested: {request.amount}")
        return RecordTransactionResponse(
            success=False,
            message="Insufficient funds for this withdrawal.",
            new_balance=current_balance
        )

    # Update balance
    new_balance = round(current_balance - request.amount, 2)
    account_data["balance"] = new_balance

    # Add transaction record
    transaction = TransactionRecord(
        timestamp=datetime.now(timezone.utc).isoformat(),
        type=request.transaction_type.lower(),
        amount=request.amount,
        new_balance=new_balance
    )
    if "transactions" not in account_data:
      account_data["transactions"] = [] # Ensure the list exists

    # Add to the beginning of the list to have newest first
    account_data["transactions"].insert(0, transaction.model_dump())

    print(f"New balance after withdrawal: ${new_balance}")

    # Save updated data
    update_account_data(request.account_id, account_data)

    return RecordTransactionResponse(
        success=True,
        message="Withdrawal successful.",
        new_balance=new_balance
    )


# --- Additional endpoints for transactions will be added below ---



